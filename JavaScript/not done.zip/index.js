// [-1, 0, 1, 2, -1, -4] 

// var threeSum = function(nums) {
//     array = [];
//     for (i=0; i<nums.length-2; i++) {
//       for (j=i+1; j<nums.length-1; j++) {
//         for (k=j+1; k<nums.length; k++) {
//           if (nums[i]+nums[j]+nums[k] == 0) {
//             array.push([nums[i],nums[j],nums[k]].sort((a,b) => a-b));
//           }
//         }
//       }
//     }
//     return array.map(JSON.stringify).reverse().filter(function(item, index, arr){ return arr.indexOf(item, index + 1) === -1; }).reverse().map(JSON.parse);
// };

// threeSum([-1, 0, 1, 2, -1, -4]);

var threeSum = function(nums) {
    nums.sort((a,b) => a-b);
    let array = [];
    // let arrayIndex = 0; 
    for (i=0; i<nums.length-2; i++) {
      for (j=i+1; j<nums.length-1; j++) {
        for (k=j+1; k<nums.length; k++) {
          if (nums[i]+nums[j]+nums[k] == 0) {
            array.push([nums[i],nums[j],nums[k]].toString());
            // arrayIndex += 1;
            // if (array.length>=2 && array[arrayIndex-1].toString() == array[arrayIndex-2].toString()) {
            //   array.pop(array[arrayIndex-1]);
            //   arrayIndex -= 1;
            // } else if  (array.length>=3 && array[arrayIndex-1].toString() == array[arrayIndex-3].toString()) {
            //   array.pop(array[arrayIndex-1]);
            //   arrayIndex -= 1;
            // }
          }
        }
      }
    }
    array = [...new Set(array)];
    return array;
};

threeSum([-4,-2,-2,-2,0,1,2,2,2,3,3,4,4,6,6]);

// console.log([1,2,3].toString())